<?php
require_once("./Base/Base.class.php");

Base::Run();